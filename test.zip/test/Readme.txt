follow following steps:-

1) install node dependancies using command
	npm install
2)run gulp command to run code
	gulp build
