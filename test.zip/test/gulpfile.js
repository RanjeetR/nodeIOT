var gulp = require('gulp');
var sass = require('gulp-ruby-sass');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var ngHtml2Js = require('browserify-ng-html2js');
var clean = require('gulp-clean');
var runSequence = require('run-sequence');
var browserSync = require('browser-sync').create();
var uglify = require('gulp-uglify');
var buffer = require('vinyl-buffer');
var sourcemaps = require('gulp-sourcemaps');
var rename = require('gulp-rename');
var eslint = require('gulp-eslint');
var inject = require('gulp-inject');
var rev = require('gulp-rev');

var production = false;

gulp.task('eslint', function() {
    return gulp.src(['js/**/*.js'])
            // eslint() attaches the lint output to the eslint property
            // of the file object so it can be used by other modules.
            .pipe(eslint())
            // eslint.format() outputs the lint results to the console.
            // Alternatively use eslint.formatEach() (see Docs).
            .pipe(eslint.format())
            // To have the process exit with an error code (1) on
            // lint error, return the stream and pipe to failOnError last.
            .pipe(eslint.failOnError());
});

gulp.task('browserify', /*['eslint'],*/ function() {
    // Grabs the app.js file
    return browserify('js/app.js',{debug: !production, insertGlobals: true})
        .transform(ngHtml2Js({
            module: 'templates' // optional module name
        }))
        // bundles it and creates a file called main.js
        .bundle()
        .pipe(source(production ? 'bundle.js' : 'bundle-min.js'))
        .pipe(buffer())
        .pipe(sourcemaps.init({loadMaps: true}))
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest('dist/auth'));
});
gulp.task('uglify', function() {
   return gulp.src('./dist/auth/bundle.js')
       .pipe(uglify())
       .pipe(rename('bundle-min.js'))
       .pipe(gulp.dest('./dist/auth/'));
});
gulp.task('sass', function() {
    return sass('sass/authstyle.scss',{compass: true, sourcemap: true, style: production ? 'compressed' : 'expanded'})
        .pipe(gulp.dest('dist/auth/css/'));
        //.pipe(browserSync.stream());
});



gulp.task('reload', function() {
    console.log('reload');
    return browserSync.reload();
});
gulp.task('watch', function() {
    gulp.watch(['js/**/*.js', 'views/**/*.html'], function() {
        runSequence('browserify', 'reload');
    });
    // Watches for changes in style.scss and runs the sass task
    gulp.watch('sass/authstyle.scss', function() {
        runSequence('sass', 'reload');
    });
});

gulp.task('server', function () {
    // Static server
    browserSync.init({
        server: {
            baseDir: "dist/auth"
        }
    });
});

gulp.task('clean', function () {
    return gulp.src('dist', {read: false})
        .pipe(clean());
});




gulp.task('copyhtml', function(){
  gulp.src('index.html')
      .pipe(gulp.dest('dist/auth/'));
});

gulp.task('rev',function(){
return gulp.src('dist/auth/bundle-min.js')
        .pipe(rev())
        .pipe(gulp.dest('dist/auth/js'));
});

gulp.task('index', function () {
  var target = gulp.src('dist/auth/index.html');
  // It's not necessary to read the files (will speed up things), we're only after their paths:
  var sources = gulp.src(['dist/auth/js/*.js'], {read: false});

  return target.pipe(inject(sources,{relative:true}))
    .pipe(gulp.dest('dist/auth/'));
});




gulp.task('build', function(){
    production = false;
    runSequence('clean','browserify', 'sass','copyhtml', 'uglify','rev','index','server','watch');
});


gulp.task('production', function() {
    production = true;
    runSequence('clean','browserify', 'uglify', 'copyfonts','server', 'sass');
});


gulp.task('default',function(){
console.log("init");
})