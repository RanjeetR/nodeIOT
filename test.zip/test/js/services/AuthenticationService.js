
    'use strict';



    AuthenticationService.$inject = ['$http','$state','$rootScope'];

    function AuthenticationService($http, $state,$rootScope,$cookies) {
        var service = {};

        service.Login = Login;
        service.Next = Next;
        return service;

         
        function Login(username,  callback) {





            var root = "http://content.guardianapis.com/search?api-key=test&q="+username+"&show-fields=thumbnail,headline&show-tags=keyword&page=1&page-size=10";
             $http.get(root)
                .success(function (response) {
                 callback(response);
                })
                .error(function(err){
                console.log("server not available",err)});

        }
        function Next(searchText,counter,callback){
            var root = "http://content.guardianapis.com/search?api-key=test&q="+searchText+"&show-fields=thumbnail,headline&show-tags=keyword&page="+counter+"&page-size=10";

            $http.get(root)
                .success(function (response) {
                    console.log('server',response);
                    callback(response);
                })
                .error(function(err){
                    console.log("server not available",err)});

        }



    }


module.exports = AuthenticationService;


