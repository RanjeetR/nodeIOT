
    'use strict';





    HomeController.$inject = ['$location', 'AuthenticationService','$state'];
    function HomeController($location, AuthenticationService,$state) {

        var vm = this;

        vm.login = login;
        vm.Next = Next;
        vm.previous = previous;
        vm.goTO = goTO;

        function login() {
            vm.dataLoading = true;

            AuthenticationService.Login(vm.username, function (response) {
                console.log("response",response);
                vm.total = response.response.pages;
                vm.counter = response.response.currentPage + 1;

                vm.items =  response.response.results;
            });
        };

        function Next(){
            console.log("next clicked",vm.username,vm.counter);
            AuthenticationService.Next(vm.username,vm.counter, function (response) {

                vm.items =  response.response.results;
                vm.counter = response.response.currentPage+1;

            });
        }
        function previous(){
            console.log("next clicked",vm.username,vm.counter);
            if(vm.counter < 1 ){
                alert('Page not Found');
                return;
            }
            AuthenticationService.Next(vm.username,vm.counter, function (response) {

                vm.items =  response.response.results;
                vm.counter = response.response.currentPage -1;
            });

        }
        function goTO(){
            console.log("next clicked",vm.username,vm.goToRecord);
            if(vm.goToRecord < 1 ){
                alert('Page not Found');
                return;
            }
            AuthenticationService.Next(vm.username,vm.goToRecord, function (response) {

                vm.items =  response.response.results;

            });

        }
    }
module.exports = HomeController;

