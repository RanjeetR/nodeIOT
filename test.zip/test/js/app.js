
"use strict";


var  angular = require('angular');
	 require('angular-ui-router');
	 require('../views/viewResult.html');
	 require('../views/home.view.html');




angular.module("authApp", ["ui.router", 'templates'])
.config(['$stateProvider',function($stateProvider){
$stateProvider
.state("login",{
	    url: "",
        templateUrl: "home.view.html",
		controller: "HomeController",
		controllerAs:"vm"

})
	.state("resultpage",{
		 url: "/result",
        		templateUrl: "viewResult.html",
				controller: "HomeController",
				controllerAs:"vm"

	});

}])

.controller('HomeController',	 require('./controller/HomeController.js'))
.factory('AuthenticationService',    require('./services/AuthenticationService.js'));

